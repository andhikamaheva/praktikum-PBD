﻿Imports System.Data
Imports System.Data.SqlClient

Public Class frm_mhs

    Dim conn As SqlConnection
    Dim connStr As String
    Dim comm As SqlCommand
    Dim statusPencarian As Boolean
    Dim exec As SqlDataReader
    Private Sub lb_nim_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles lb_nim.Click

    End Sub

    Private Sub Label5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles lb_kota.Click

    End Sub

    Private Sub bt_keluar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles bt_keluar.Click
        End
    End Sub

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        connStr = "server=.\SQLEXPRESS;database=PBD;integrated security=true;MultipleActiveResultSets=true"
        conn = New SqlConnection(connStr)
    End Sub

    Private Sub bt_cari_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles bt_cari.Click
        Try
        conn.Open()
        Dim query As String
        Dim nim = txt_nim.Text

        query = "select * from mahasiswa where nim = '" & nim & "'"
        comm = New SqlCommand(query, conn)
        exec = comm.ExecuteReader


        While exec.Read
            txt_nama.Text = exec(1)
            txt_alamat.Text = exec(2)
            txt_kota.Text = exec(3)
            If exec(4) = "P" Then
                rd_pria.Checked = True
            Else
                rd_perempuan.Checked = True
            End If
            If exec(5) = "B" Then
                rd_belum.Checked = True
            Else
                rd_menikah.Checked = True
            End If
        End While
            statusPencarian = True
        Catch ex As Exception
            MsgBox("Data tidak ada!", MsgBoxStyle.OkOnly And MsgBoxStyle.Information, "Failed!")
            statusPencarian = False
        End Try
        comm.Dispose() 'close sqlCommand
        exec.Close() ' close sqlDataReader
        conn.Close() ' close koneksi
    End Sub

    Private Sub txt_nim_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txt_nim.TextChanged

    End Sub

End Class
