﻿Imports System.Data
Imports System.Data.SqlClient

Public Class Tugas

    Dim comm As SqlCommand
    Dim exec As SqlDataReader
    Dim query As String

    Dim connStr As String = "server=.\SQLEXPRESS;database=PUTRAJAYA;integrated security=true;MultipleActiveResultSets=true"
    Dim conn As New SqlConnection(connStr)

    Private Sub btn_keluar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_keluar.Click
        End
    End Sub

    Private Sub Tugas_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        
        btn_tambah.Enabled = True
        btn_ubah.Enabled = False
        conn.Open()
        query = "select namadepartemen from departemen"
        comm = New SqlCommand(query, conn)
        exec = comm.ExecuteReader

        While exec.Read
            cbo_Dept.Items.Add(exec(0))
        End While
        comm.Dispose()
        exec.Close()
        'conn.Close()

    End Sub

    Private Sub cbo_Dept_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cbo_Dept.SelectedIndexChanged
        'conn.Open()
        query = "select iddepartemen from departemen where namadepartemen = '" & cbo_Dept.Text & "'"
        comm = New SqlCommand(query, conn)
        txt_id.Text = comm.ExecuteScalar()
        comm.Dispose()
        'conn.Close()

        'conn.Open()
        query = "select count(*)+1 from karyawan where idkaryawan like 'k" & txt_id.Text & "%'"
        Dim nik As Integer
        comm = New SqlCommand(query, conn)
        nik = comm.ExecuteScalar()

        Dim nik1 As String
        If nik < 10 Then
            nik1 = "K" + txt_id.Text + "0" + nik.ToString()
        Else
            nik1 = "K" + txt_id.Text + nik.ToString()
        End If

        txt_nik.Text = nik1
        comm.Dispose()
        'conn.Close()

    End Sub

    Private Sub TextBox4_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txt_nik.TextChanged

    End Sub

    Private Sub btn_cari_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_cari.Click
        'conn.Open()
        txt_id.Text = ""
        txt_nama.Text = ""
        txt_pin.Text = ""
        query = "select departemen.namadepartemen, karyawan.namakaryawan, karyawan.pin, karyawan.iddepartemen from karyawan inner join departemen  on departemen.iddepartemen = karyawan.iddepartemen where idkaryawan =  '" & txt_nik.Text & "'"
        comm = New SqlCommand(query, conn)
        exec = comm.ExecuteReader()

        While exec.Read
            cbo_Dept.Text = exec(0)
            txt_nama.Text = exec(1)
            txt_pin.Text = exec(2)
            txt_id.Text = exec(3)
        End While

        If txt_id.Text <> "" And txt_nama.Text <> "" And txt_nik.Text <> "" And txt_pin.Text <> "" Then
            btn_tambah.Enabled = False
            btn_ubah.Enabled = True


        Else
            btn_tambah.Enabled = True
            btn_ubah.Enabled = False
        End If
        comm.Dispose()
        exec.Close()
        'conn.Close()
    End Sub

    Private Sub btn_tambah_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_tambah.Click
        query = "insert into karyawan values('" & txt_nik.Text & "','" & txt_nama.Text & "','" & txt_pin.Text & "'," & txt_id.Text & ")"
        comm = New SqlCommand(query, conn)
        comm.ExecuteNonQuery()

        comm.Dispose()
    End Sub

    Private Sub btn_ubah_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_ubah.Click
        query = "update KARYAWAN set NAMAKARYAWAN  = '" & txt_nama.Text & "', PIN = '" & txt_pin.Text & "' where IDKARYAWAN = '" & txt_nik.Text & "'"
        comm = New SqlCommand(query, conn)

        comm.ExecuteNonQuery()
        comm.Dispose()
    End Sub
End Class