﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frm_mhs
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lb_nim = New System.Windows.Forms.Label()
        Me.lb_alamat = New System.Windows.Forms.Label()
        Me.lb_nama = New System.Windows.Forms.Label()
        Me.lb_jenis = New System.Windows.Forms.Label()
        Me.lb_kota = New System.Windows.Forms.Label()
        Me.lb_status = New System.Windows.Forms.Label()
        Me.txt_nim = New System.Windows.Forms.TextBox()
        Me.txt_kota = New System.Windows.Forms.TextBox()
        Me.txt_alamat = New System.Windows.Forms.TextBox()
        Me.txt_nama = New System.Windows.Forms.TextBox()
        Me.bt_cari = New System.Windows.Forms.Button()
        Me.gp_kelamin = New System.Windows.Forms.GroupBox()
        Me.rd_pria = New System.Windows.Forms.RadioButton()
        Me.rd_perempuan = New System.Windows.Forms.RadioButton()
        Me.gp_status = New System.Windows.Forms.GroupBox()
        Me.rd_menikah = New System.Windows.Forms.RadioButton()
        Me.rd_belum = New System.Windows.Forms.RadioButton()
        Me.bt_batal = New System.Windows.Forms.Button()
        Me.bt_simpan = New System.Windows.Forms.Button()
        Me.bt_keluar = New System.Windows.Forms.Button()
        Me.gp_kelamin.SuspendLayout()
        Me.gp_status.SuspendLayout()
        Me.SuspendLayout()
        '
        'lb_nim
        '
        Me.lb_nim.AutoSize = True
        Me.lb_nim.Location = New System.Drawing.Point(78, 37)
        Me.lb_nim.Name = "lb_nim"
        Me.lb_nim.Size = New System.Drawing.Size(25, 13)
        Me.lb_nim.TabIndex = 0
        Me.lb_nim.Text = "Nim"
        '
        'lb_alamat
        '
        Me.lb_alamat.AutoSize = True
        Me.lb_alamat.Location = New System.Drawing.Point(78, 120)
        Me.lb_alamat.Name = "lb_alamat"
        Me.lb_alamat.Size = New System.Drawing.Size(39, 13)
        Me.lb_alamat.TabIndex = 1
        Me.lb_alamat.Text = "Alamat"
        '
        'lb_nama
        '
        Me.lb_nama.AutoSize = True
        Me.lb_nama.Location = New System.Drawing.Point(78, 80)
        Me.lb_nama.Name = "lb_nama"
        Me.lb_nama.Size = New System.Drawing.Size(35, 13)
        Me.lb_nama.TabIndex = 2
        Me.lb_nama.Text = "Nama"
        '
        'lb_jenis
        '
        Me.lb_jenis.AutoSize = True
        Me.lb_jenis.Location = New System.Drawing.Point(78, 196)
        Me.lb_jenis.Name = "lb_jenis"
        Me.lb_jenis.Size = New System.Drawing.Size(71, 13)
        Me.lb_jenis.TabIndex = 3
        Me.lb_jenis.Text = "Jenis Kelamin"
        '
        'lb_kota
        '
        Me.lb_kota.AutoSize = True
        Me.lb_kota.Location = New System.Drawing.Point(78, 160)
        Me.lb_kota.Name = "lb_kota"
        Me.lb_kota.Size = New System.Drawing.Size(29, 13)
        Me.lb_kota.TabIndex = 4
        Me.lb_kota.Text = "Kota"
        '
        'lb_status
        '
        Me.lb_status.AutoSize = True
        Me.lb_status.Location = New System.Drawing.Point(78, 270)
        Me.lb_status.Name = "lb_status"
        Me.lb_status.Size = New System.Drawing.Size(68, 13)
        Me.lb_status.TabIndex = 5
        Me.lb_status.Text = "Status Nikah"
        '
        'txt_nim
        '
        Me.txt_nim.Location = New System.Drawing.Point(169, 37)
        Me.txt_nim.Name = "txt_nim"
        Me.txt_nim.Size = New System.Drawing.Size(146, 20)
        Me.txt_nim.TabIndex = 6
        '
        'txt_kota
        '
        Me.txt_kota.Location = New System.Drawing.Point(169, 153)
        Me.txt_kota.Name = "txt_kota"
        Me.txt_kota.Size = New System.Drawing.Size(146, 20)
        Me.txt_kota.TabIndex = 7
        '
        'txt_alamat
        '
        Me.txt_alamat.Location = New System.Drawing.Point(169, 113)
        Me.txt_alamat.Name = "txt_alamat"
        Me.txt_alamat.Size = New System.Drawing.Size(146, 20)
        Me.txt_alamat.TabIndex = 8
        '
        'txt_nama
        '
        Me.txt_nama.Location = New System.Drawing.Point(169, 73)
        Me.txt_nama.Name = "txt_nama"
        Me.txt_nama.Size = New System.Drawing.Size(146, 20)
        Me.txt_nama.TabIndex = 9
        '
        'bt_cari
        '
        Me.bt_cari.Location = New System.Drawing.Point(342, 33)
        Me.bt_cari.Name = "bt_cari"
        Me.bt_cari.Size = New System.Drawing.Size(75, 23)
        Me.bt_cari.TabIndex = 10
        Me.bt_cari.Text = "Cari"
        Me.bt_cari.UseVisualStyleBackColor = True
        '
        'gp_kelamin
        '
        Me.gp_kelamin.Controls.Add(Me.rd_perempuan)
        Me.gp_kelamin.Controls.Add(Me.rd_pria)
        Me.gp_kelamin.Location = New System.Drawing.Point(169, 196)
        Me.gp_kelamin.Name = "gp_kelamin"
        Me.gp_kelamin.Size = New System.Drawing.Size(248, 55)
        Me.gp_kelamin.TabIndex = 11
        Me.gp_kelamin.TabStop = False
        Me.gp_kelamin.Text = "Jenis Kelamin"
        '
        'rd_pria
        '
        Me.rd_pria.AutoSize = True
        Me.rd_pria.Location = New System.Drawing.Point(18, 20)
        Me.rd_pria.Name = "rd_pria"
        Me.rd_pria.Size = New System.Drawing.Size(43, 17)
        Me.rd_pria.TabIndex = 0
        Me.rd_pria.TabStop = True
        Me.rd_pria.Text = "Pria"
        Me.rd_pria.UseVisualStyleBackColor = True
        '
        'rd_perempuan
        '
        Me.rd_perempuan.AutoSize = True
        Me.rd_perempuan.Location = New System.Drawing.Point(134, 20)
        Me.rd_perempuan.Name = "rd_perempuan"
        Me.rd_perempuan.Size = New System.Drawing.Size(79, 17)
        Me.rd_perempuan.TabIndex = 1
        Me.rd_perempuan.TabStop = True
        Me.rd_perempuan.Text = "Perepmuan"
        Me.rd_perempuan.UseVisualStyleBackColor = True
        '
        'gp_status
        '
        Me.gp_status.Controls.Add(Me.rd_belum)
        Me.gp_status.Controls.Add(Me.rd_menikah)
        Me.gp_status.Location = New System.Drawing.Point(169, 270)
        Me.gp_status.Name = "gp_status"
        Me.gp_status.Size = New System.Drawing.Size(248, 48)
        Me.gp_status.TabIndex = 12
        Me.gp_status.TabStop = False
        Me.gp_status.Text = "Status Nikah"
        '
        'rd_menikah
        '
        Me.rd_menikah.AutoSize = True
        Me.rd_menikah.Location = New System.Drawing.Point(18, 19)
        Me.rd_menikah.Name = "rd_menikah"
        Me.rd_menikah.Size = New System.Drawing.Size(66, 17)
        Me.rd_menikah.TabIndex = 2
        Me.rd_menikah.TabStop = True
        Me.rd_menikah.Text = "Menikah"
        Me.rd_menikah.UseVisualStyleBackColor = True
        '
        'rd_belum
        '
        Me.rd_belum.AutoSize = True
        Me.rd_belum.Location = New System.Drawing.Point(134, 19)
        Me.rd_belum.Name = "rd_belum"
        Me.rd_belum.Size = New System.Drawing.Size(98, 17)
        Me.rd_belum.TabIndex = 3
        Me.rd_belum.TabStop = True
        Me.rd_belum.Text = "Belum Menikah"
        Me.rd_belum.UseVisualStyleBackColor = True
        '
        'bt_batal
        '
        Me.bt_batal.Location = New System.Drawing.Point(81, 358)
        Me.bt_batal.Name = "bt_batal"
        Me.bt_batal.Size = New System.Drawing.Size(75, 23)
        Me.bt_batal.TabIndex = 13
        Me.bt_batal.Text = "Batal"
        Me.bt_batal.UseVisualStyleBackColor = True
        '
        'bt_simpan
        '
        Me.bt_simpan.Location = New System.Drawing.Point(209, 358)
        Me.bt_simpan.Name = "bt_simpan"
        Me.bt_simpan.Size = New System.Drawing.Size(75, 23)
        Me.bt_simpan.TabIndex = 14
        Me.bt_simpan.Text = "Simpan"
        Me.bt_simpan.UseVisualStyleBackColor = True
        '
        'bt_keluar
        '
        Me.bt_keluar.Location = New System.Drawing.Point(342, 358)
        Me.bt_keluar.Name = "bt_keluar"
        Me.bt_keluar.Size = New System.Drawing.Size(75, 23)
        Me.bt_keluar.TabIndex = 15
        Me.bt_keluar.Text = "Keluar"
        Me.bt_keluar.UseVisualStyleBackColor = True
        '
        'frm_mhs
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.ClientSize = New System.Drawing.Size(489, 446)
        Me.Controls.Add(Me.bt_keluar)
        Me.Controls.Add(Me.bt_simpan)
        Me.Controls.Add(Me.bt_batal)
        Me.Controls.Add(Me.gp_status)
        Me.Controls.Add(Me.gp_kelamin)
        Me.Controls.Add(Me.bt_cari)
        Me.Controls.Add(Me.txt_nama)
        Me.Controls.Add(Me.txt_alamat)
        Me.Controls.Add(Me.txt_kota)
        Me.Controls.Add(Me.txt_nim)
        Me.Controls.Add(Me.lb_status)
        Me.Controls.Add(Me.lb_kota)
        Me.Controls.Add(Me.lb_jenis)
        Me.Controls.Add(Me.lb_nama)
        Me.Controls.Add(Me.lb_alamat)
        Me.Controls.Add(Me.lb_nim)
        Me.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Name = "frm_mhs"
        Me.Text = "Manage Mahasiswa"
        Me.gp_kelamin.ResumeLayout(False)
        Me.gp_kelamin.PerformLayout()
        Me.gp_status.ResumeLayout(False)
        Me.gp_status.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents lb_nim As System.Windows.Forms.Label
    Friend WithEvents lb_alamat As System.Windows.Forms.Label
    Friend WithEvents lb_nama As System.Windows.Forms.Label
    Friend WithEvents lb_jenis As System.Windows.Forms.Label
    Friend WithEvents lb_kota As System.Windows.Forms.Label
    Friend WithEvents lb_status As System.Windows.Forms.Label
    Friend WithEvents txt_nim As System.Windows.Forms.TextBox
    Friend WithEvents txt_kota As System.Windows.Forms.TextBox
    Friend WithEvents txt_alamat As System.Windows.Forms.TextBox
    Friend WithEvents txt_nama As System.Windows.Forms.TextBox
    Friend WithEvents bt_cari As System.Windows.Forms.Button
    Friend WithEvents gp_kelamin As System.Windows.Forms.GroupBox
    Friend WithEvents rd_perempuan As System.Windows.Forms.RadioButton
    Friend WithEvents rd_pria As System.Windows.Forms.RadioButton
    Friend WithEvents gp_status As System.Windows.Forms.GroupBox
    Friend WithEvents rd_belum As System.Windows.Forms.RadioButton
    Friend WithEvents rd_menikah As System.Windows.Forms.RadioButton
    Friend WithEvents bt_batal As System.Windows.Forms.Button
    Friend WithEvents bt_simpan As System.Windows.Forms.Button
    Friend WithEvents bt_keluar As System.Windows.Forms.Button

End Class
