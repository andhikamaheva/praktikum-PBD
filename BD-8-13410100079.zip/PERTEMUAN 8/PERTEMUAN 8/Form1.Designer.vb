﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.dgvDosen = New System.Windows.Forms.DataGridView()
        Me.NID = New System.Windows.Forms.Label()
        Me.Nama = New System.Windows.Forms.Label()
        Me.txtNID = New System.Windows.Forms.TextBox()
        Me.txtNama = New System.Windows.Forms.TextBox()
        Me.btnTambah = New System.Windows.Forms.Button()
        Me.btnKeluar = New System.Windows.Forms.Button()
        Me.btnUbah = New System.Windows.Forms.Button()
        CType(Me.dgvDosen, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'dgvDosen
        '
        Me.dgvDosen.AllowUserToAddRows = False
        Me.dgvDosen.AllowUserToDeleteRows = False
        Me.dgvDosen.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgvDosen.Location = New System.Drawing.Point(68, 12)
        Me.dgvDosen.Name = "dgvDosen"
        Me.dgvDosen.Size = New System.Drawing.Size(507, 243)
        Me.dgvDosen.TabIndex = 0
        '
        'NID
        '
        Me.NID.AutoSize = True
        Me.NID.Location = New System.Drawing.Point(65, 318)
        Me.NID.Name = "NID"
        Me.NID.Size = New System.Drawing.Size(26, 13)
        Me.NID.TabIndex = 1
        Me.NID.Text = "NID"
        '
        'Nama
        '
        Me.Nama.AutoSize = True
        Me.Nama.Location = New System.Drawing.Point(65, 357)
        Me.Nama.Name = "Nama"
        Me.Nama.Size = New System.Drawing.Size(35, 13)
        Me.Nama.TabIndex = 2
        Me.Nama.Text = "Nama"
        '
        'txtNID
        '
        Me.txtNID.Location = New System.Drawing.Point(174, 311)
        Me.txtNID.Name = "txtNID"
        Me.txtNID.Size = New System.Drawing.Size(143, 20)
        Me.txtNID.TabIndex = 3
        '
        'txtNama
        '
        Me.txtNama.Location = New System.Drawing.Point(174, 350)
        Me.txtNama.Name = "txtNama"
        Me.txtNama.Size = New System.Drawing.Size(294, 20)
        Me.txtNama.TabIndex = 4
        '
        'btnTambah
        '
        Me.btnTambah.Location = New System.Drawing.Point(292, 391)
        Me.btnTambah.Name = "btnTambah"
        Me.btnTambah.Size = New System.Drawing.Size(75, 23)
        Me.btnTambah.TabIndex = 5
        Me.btnTambah.Text = "Tambah"
        Me.btnTambah.UseVisualStyleBackColor = True
        '
        'btnKeluar
        '
        Me.btnKeluar.Location = New System.Drawing.Point(500, 391)
        Me.btnKeluar.Name = "btnKeluar"
        Me.btnKeluar.Size = New System.Drawing.Size(75, 23)
        Me.btnKeluar.TabIndex = 6
        Me.btnKeluar.Text = "Keluar"
        Me.btnKeluar.UseVisualStyleBackColor = True
        '
        'btnUbah
        '
        Me.btnUbah.Location = New System.Drawing.Point(393, 391)
        Me.btnUbah.Name = "btnUbah"
        Me.btnUbah.Size = New System.Drawing.Size(75, 23)
        Me.btnUbah.TabIndex = 7
        Me.btnUbah.Text = "Ubah"
        Me.btnUbah.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(620, 428)
        Me.Controls.Add(Me.btnUbah)
        Me.Controls.Add(Me.btnKeluar)
        Me.Controls.Add(Me.btnTambah)
        Me.Controls.Add(Me.txtNama)
        Me.Controls.Add(Me.txtNID)
        Me.Controls.Add(Me.Nama)
        Me.Controls.Add(Me.NID)
        Me.Controls.Add(Me.dgvDosen)
        Me.Name = "Form1"
        Me.Text = "Form1"
        CType(Me.dgvDosen, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents dgvDosen As System.Windows.Forms.DataGridView
    Friend WithEvents NID As System.Windows.Forms.Label
    Friend WithEvents Nama As System.Windows.Forms.Label
    Friend WithEvents txtNID As System.Windows.Forms.TextBox
    Friend WithEvents txtNama As System.Windows.Forms.TextBox
    Friend WithEvents btnTambah As System.Windows.Forms.Button
    Friend WithEvents btnKeluar As System.Windows.Forms.Button
    Friend WithEvents btnUbah As System.Windows.Forms.Button

End Class
