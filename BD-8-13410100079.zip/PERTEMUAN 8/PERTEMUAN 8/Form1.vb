﻿Imports System.Data
Imports System.Data.SqlClient

Public Class Form1
    Dim connStr As String = "server=192.168.100.6,1433\SQLEXPRESS;database=PRAKTEK;MultipleActiveResultSets=true;user id = p13410100079; password = 13410100079"
    Dim conn As New SqlConnection(connStr)
    Dim comm As SqlCommand

    Dim dtDosen As DataTable
    Dim adapter As SqlDataAdapter
    Dim query As String

    'Deklarasi Dataset
    Dim dsPBD As DataSet
    Dim colNID As DataColumn
    Dim colNama As DataColumn
    Dim colTgl As DataColumn
    Dim pkDsn() As DataColumn
    Dim drDosen As DataRow



    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        
        'buat DB
        dsPBD = New DataSet("PBD")


        'buat table
        dtDosen = New DataTable("Dosen")

        'isi column
        colNID = New DataColumn("NID")
        colNID.DataType = Type.GetType("System.String")
        colNID.MaxLength = 6


        colNama = New DataColumn("Nama")
        colNama.DataType = Type.GetType("System.String")
        colNama.MaxLength = 100
        colNama.AllowDBNull = False


        dtDosen.Columns.Add(colNID)
        dtDosen.Columns.Add(colNama)


        pkDsn = New DataColumn() {colNID}
        dtDosen.PrimaryKey = pkDsn
        dsPBD.Tables.Add(dtDosen)

        conn.Open()
        query = "select * from dosen"
        comm = New SqlCommand(query, conn)
        adapter = New SqlDataAdapter(query, conn)
        adapter.Fill(dtDosen)
        dgvDosen.DataSource = dsPBD.Tables(0)
        conn.Close()
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnTambah.Click
        drDosen = dtDosen.NewRow
        drDosen("NID") = txtNID.Text
        drDosen("Nama") = txtNama.Text
        dtDosen.Rows.Add(drDosen)
        dgvDosen.DataSource = ""
        dgvDosen.DataSource = dtDosen
    End Sub

    Private Sub btnKeluar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnKeluar.Click
        End
    End Sub

    Private Sub btnUbah_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnUbah.Click
        Dim drCari As DataRow = dtDosen.Rows.Find(txtNID.Text)
        If Not IsNothing(drCari) Then
            drCari.BeginEdit()
            drCari("Nama") = txtNama.Text
            drCari.EndEdit()
            dgvDosen.DataSource = ""
            dgvDosen.DataSource = dtDosen
        Else
            MsgBox("Data Tidak Ditemukan", MsgBoxStyle.OkOnly, "Failed")
        End If
    End Sub
End Class
