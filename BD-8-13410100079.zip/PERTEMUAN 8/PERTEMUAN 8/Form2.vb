﻿
Imports System.Data
Imports System.Data.SqlClient

Public Class Form2
    Dim connStr As String = "server=192.168.100.6,1433\SQLEXPRESS;database=PRAKTEK;MultipleActiveResultSets=true;user id = p13410100079; password = 13410100079"
    Dim conn As New SqlConnection(connStr)
    Dim comm As SqlCommand
    Dim query As String
    Dim adapter As SqlDataAdapter

    Dim dsPutra As DataSet
    Dim dtKonsumen As DataTable

    Dim colID As DataColumn
    Dim colNama As DataColumn
    Dim colAlamat As DataColumn
    Dim colKota As DataColumn
    Dim colTelp As DataColumn
    Dim pkKon() As DataColumn
    Dim drCari As DataRow



    Private Sub Form2_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        btnUbah.Enabled = False

        dsPutra = New DataSet("PUTRAJAYA")
        dtKonsumen = New DataTable("Konsumen")

        colID = New DataColumn("IDKONSUMEN")
        colID.DataType = Type.GetType("System.Int32")



        colNama = New DataColumn("NAMAKONSUMEN")
        colNama.DataType = Type.GetType("System.String")
        colNama.MaxLength = 100


        colAlamat = New DataColumn("ALAMAT")
        colAlamat.DataType = Type.GetType("System.String")
        colAlamat.MaxLength = 200


        colKota = New DataColumn("KOTA")
        colKota.DataType = Type.GetType("System.String")
        colKota.MaxLength = 50
        
        colTelp = New DataColumn("NOTELP")
        colTelp.DataType = Type.GetType("System.String")
        colTelp.MaxLength = 20

        dtKonsumen.Columns.Add(colID)
        dtKonsumen.Columns.Add(colNama)
        dtKonsumen.Columns.Add(colAlamat)
        dtKonsumen.Columns.Add(colKota)
        dtKonsumen.Columns.Add(colTelp)

        pkKon = New DataColumn() {colID}

        dtKonsumen.PrimaryKey = pkKon

        dsPutra.Tables.Add(dtKonsumen)

        conn.Open()
        query = "select * from konsumen"
        comm = New SqlCommand(query, conn)
        adapter = New SqlDataAdapter(query, conn)
        adapter.Fill(dtKonsumen)
        dgvKonsumen.DataSource = dtKonsumen
        conn.Close()
    End Sub

    Private Sub btnKeluar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnKeluar.Click
        End
    End Sub

    Private Sub btnCari_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCari.Click
        drCari = dtKonsumen.Rows.Find(txtID.Text)

        If Not IsNothing(drCari) Then
            txtNama.Text = drCari("NAMAKONSUMEN")
            txtAlamat.Text = drCari("ALAMAT")
            txtKota.Text = drCari("KOTA")
            txtNoTelp.Text = drCari("NOTELP")
            btnTambah.Enabled = False
            btnUbah.Enabled = True

        Else
            btnTambah.Enabled = True
            btnUbah.Enabled = False
            MsgBox("Data tidak ada!", MsgBoxStyle.OkOnly, "Failed!")

        End If

    End Sub

    Private Sub btnUbah_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnUbah.Click

        drCari.BeginEdit()
        drCari("NAMAKONSUMEN") = txtNama.Text
        drCari("ALAMAT") = txtAlamat.Text
        drCari("KOTA") = txtKota.Text
        drCari("NOTELP") = txtNoTelp.Text
        drCari.EndEdit()
        dgvKonsumen.DataSource = ""
        dgvKonsumen.DataSource = dtKonsumen
        clear()
        
    End Sub

    Private Sub clear()
        txtID.Text = ""
        txtNama.Text = ""
        txtAlamat.Text = ""
        txtKota.Text = ""
        txtNoTelp.Text = ""
        btnTambah.Enabled = True
        btnUbah.Enabled = False
    End Sub

    Private Sub btnTambah_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnTambah.Click
        drCari = dtKonsumen.NewRow

        drCari("IDKONSUMEN") = txtID.Text
        drCari("NAMAKONSUMEN") = txtNama.Text
        drCari("ALAMAT") = txtAlamat.Text
        drCari("KOTA") = txtKota.Text
        drCari("NOTELP") = txtNoTelp.Text

        dtKonsumen.Rows.Add(drCari)
        clear()

    End Sub
End Class