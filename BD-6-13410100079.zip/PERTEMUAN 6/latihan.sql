

-- LATIHAN 1
CREATE TRIGGER tg_tambahmk
ON MAHASISWA
WITH ENCRYPTION
FOR INSERT
AS
	BEGIN
		DECLARE @NIM CHAR(11);
		
		
		SELECT @NIM = NIM FROM INSERTED
		
		INSERT INTO NILAI VALUES (@NIM,'MK-102','NN',NULL,NULL,NULL)
	END;
	
	SELECT * FROM NILAI WHERE KODE_MK = 'MK-102' AND NID = 'NN'
	SELECT * FROM MAHASISWA
	
CREATE TRIGGER tg_deletemhs
on nilai
for delete
as
	begin
		declare @nim char(11);
		
		select * from deleted
		
		
		delete mahasiswa
		where nim = @nim
		
	end;
	
	delete nilai
	where nim = '13410100074'
	
-- latihan 2

create trigger tg_hapusmhs
on mahasiswa
instead of delete
as
	begin
		declare @nim char (11), @jmlh int;
		set @nim = (select nim from deleted)
		set @jmlh = (select count(*) from nilai where nim = @nim)
		
		if @jmlh > 0
		begin
			delete nilai where nim = @nim	
			delete mahasiswa where nim = @nim
		end
		
		else
		
			begin
				delete mahasiswa where nim = @nim
			end
	end; 
	
	
	insert into mahasiswa values ('13410100074','chakim','surabaya','surabaya','P','B','11-11-2014')
	select * from mahasiswa
	
	delete mahasiswa where nim = '13410100074'
	
	select * from nilai
