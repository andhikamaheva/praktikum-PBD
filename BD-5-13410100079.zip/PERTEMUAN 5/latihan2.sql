-- LATIHAN 1
CREATE PROCEDURE spTampil
@angkatan char(4)
AS
	BEGIN
		SELECT NIM, NAMA, ALAMAT FROM mahasiswa WHERE nim like RIGHT(@ANGKATAN,2)+'%';
	END


BEGIN
	DECLARE @ANGKATAN CHAR (4);
	
	SET @angkatan = '2005';
	EXEC spTampil @angkatan
	
	
END;

-- LATIHAN 2
CREATE PROCEDURE sp_TambahMahasiswa
@nim char(11), @nama varchar (100), @alamat varchar(100), @kota varchar (50), @jns_kelamin char(1),
@sts_nikah char(1), @TGL_LAHIR datetime
AS
	BEGIN
		INSERT INTO mahasiswa VALUES (@nim, @nama, @alamat, @kota, @jns_kelamin, @sts_nikah, @TGL_LAHIR);
	END;

-- LATIHAN 3
CREATE PROCEDURE sp_HapusMahasiswa
@nim char (11)
AS
	BEGIN
		DELETE mahasiswa
		WHERE nim = @nim
		
	END;
	
-- LATIHAN 4
CREATE FUNCTION fn_HitungUsia (@tgl_lahir datetime)
returns int
	AS
	BEGIN
		DECLARE @UMUR INT;
		SET @UMUR = DATEDIFF (YY,@TGL_LAHIR,GETDATE());
		RETURN @UMUR;
	END;
	

BEGIN
	DECLARE @TGL_LAHIR DATETIME, @usia int;
	
	SELECT @TGL_LAHIR=TGL_LAHIR FROM mahasiswa WHERE nim =  '13410100079';
	
	 set @usia = dbo.fn_HitungUsia (@tgl_lahir);
	 print @usia
END;	

-- LATIHAN 5

CREATE FUNCTION fn_HitungNikah (@nim char (11))
returns char(1)
	BEGIN
		declare @status char(1), @umur int, @kelamin char(1);
		select 	@umur=datediff(yy,tgl_lahir,getdate()) , @kelamin = jns_kelamin from mahasiswa where nim = @nim;
		if @umur >= 24 and @kelamin = 'p'
			begin
				set @status = 'M'
			end
		if @umur < 24 and @kelamin = 'p'
			begin
				set @status = 'B'
			end
	END
	
	select jns_kelamin from mahasiswa