CREATE FUNCTION f_nim_totbyr_nimpendek1 (@PPN INT, @BELI INT)
RETURNS NUMERIC (11)
	AS
	BEGIN
		-- CEK PPN
		IF @PPN >=1 AND @PPN <=50
		BEGIN
			SET @PPN = @PPN
		END
		ELSE
			BEGIN
				SET @PPN = 0	
			END
		-- CEK BAYAR
		IF @BELI <= 0
			BEGIN
				SET @BELI = 0
			END
		ELSE
			BEGIN
				SET @BELI = @BELI
			END
		-- PERHITUNGAN
		DECLARE @TOTAL NUMERIC(11);
		
		SET @TOTAL = (@BELI+(@PPN*1.0/100*@BELI))
		RETURN @TOTAL
	END

-- EKSEKUSI FUNCTION
BEGIN
	DECLARE @PPN INT, @BELI INT, @TOTAL INT;
	
	SET @PPN = 50; SET @BELI = 10000;
	SET @total = dbo.f_nim_totbyr_nimpendek1 (@PPN, @BELI)
	PRINT @TOTAL;
	
END
