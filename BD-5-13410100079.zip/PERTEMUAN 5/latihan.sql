CREATE PROCEDURE spTampil1
@angkatan char(4), @kota varchar(100)
AS
	BEGIN
		SELECT NIM, NAMA, ALAMAT FROM mahasiswa WHERE nim like RIGHT(@ANGKATAN,2)+'%' and kota = @kota;
	END


BEGIN
	DECLARE @ANGKATAN CHAR (4), @kota varchar(100);
	
	SET @angkatan = '2006';
	set @kota = 'surabaya'
	EXEC spTampil1 @angkatan, @kota
	
	
END;

select * from mahasiswa

